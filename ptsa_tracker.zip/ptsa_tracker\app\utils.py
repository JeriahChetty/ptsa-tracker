import os
ALLOWED = {'pdf','png','jpg','jpeg','webp'}

def allowed_file(fname: str) -> bool:
    return '.' in fname and fname.rsplit('.',1)[1].lower() in ALLOWED

def secure_join(base, *paths):
    path = os.path.join(base, *paths)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path
