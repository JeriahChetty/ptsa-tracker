# seed_data.py
from __future__ import annotations

from datetime import datetime, timedelta, date
from typing import Optional, Dict, Any, Iterable

from werkzeug.security import generate_password_hash

from app import create_app
from app.extensions import db
from app.models import MeasureAssignment

ADMIN_EMAIL = "admin@ptsa.com"
ADMIN_PASSWORD = "Admin123!"


# ---------- helpers ----------
def get_or_create(model, defaults: Optional[Dict[str, Any]] = None, **kwargs):
    """
    Simple get_or_create by equality on kwargs.
    """
    instance = model.query.filter_by(**kwargs).first()
    if instance:
        return instance, False
    params = dict(kwargs)
    if defaults:
        params.update(defaults)
    instance = model(**params)
    db.session.add(instance)
    return instance, True


def ensure_tables():
    """
    Make sure tables exist (safe even if you use migrations).
    """
    db.create_all()


# ---------- seed blocks ----------
def seed_admin():
    from app.models import User
    admin, created = get_or_create(
        User,
        email=ADMIN_EMAIL,
        defaults=dict(
            password=generate_password_hash(ADMIN_PASSWORD),
            role="admin",
            is_active=True,
            company_id=None,
        ),
    )
    # If it existed but was not admin/active, ensure minimal correctness:
    changed = False
    if admin.role != "admin":
        admin.role = "admin"
        changed = True
    if not admin.is_active:
        admin.is_active = True
        changed = True
    if changed:
        db.session.add(admin)
    return created or changed


def seed_companies():
    from app.models import Company
    payload = [
        dict(
            name="Acme Tooling",
            region="Gauteng",
            industry_category="Automotive",
            tech_resources="Injection moulds, press tools, EDM, CNC machining",
            human_resources="8 toolmakers, 3 apprentices, 5 CNC operators",
            membership="Member",
        ),
        dict(
            name="Bravo Plastics",
            region="KwaZulu-Natal",
            industry_category="Plastics",
            tech_resources="Mould maintenance, CNC turning",
            human_resources="6 toolmakers, 2 apprentices",
            membership="Non-member",
        ),
        dict(
            name="Cobalt Engineering",
            region="Western Cape",
            industry_category="General Engineering",
            tech_resources="General fabrication, jigs & fixtures",
            human_resources="4 fitters, 2 welders",
            membership="Member",
        ),
    ]

    created_any = False
    for data in payload:
        _, created = get_or_create(Company, name=data["name"], defaults=data)
        created_any = created_any or created
    return created_any


def seed_company_users():
    """
    Add one company user for the first two companies (demo).
    Passwords: 'Company123!'
    """
    from app.models import User, Company
    comp1 = Company.query.filter_by(name="Acme Tooling").first()
    comp2 = Company.query.filter_by(name="Bravo Plastics").first()

    changed = False
    if comp1:
        _, created = get_or_create(
            User,
            email="user.acme@ptsa.local",
            defaults=dict(
                password=generate_password_hash("Company123!"),
                role="company",
                is_active=True,
                company_id=comp1.id,
            ),
        )
        changed = changed or created
    if comp2:
        _, created = get_or_create(
            User,
            email="user.bravo@ptsa.local",
            defaults=dict(
                password=generate_password_hash("Company123!"),
                role="company",
                is_active=True,
                company_id=comp2.id,
            ),
        )
        changed = changed or created
    return changed


def seed_measures():
    """
    Create a few measures with sensible defaults.
    """
    from app.models import Measure
    payload = [
        dict(
            name="5S Implementation",
            description="Roll out 5S across the machining area.",  # Will be renamed to 'measure detail' in templates
            target="Sustain 5S score > 85% for 3 consecutive audits.",
            departments="Operations",
            responsible="Production Manager",
            participants="All operators",
            start_date=date.today(),
            end_date=date.today() + timedelta(days=45),
        ),
        dict(
            name="Preventive Maintenance Program",
            description="Establish and execute PM schedule for critical machines.",
            target="Zero critical unplanned downtime for 60 days.",
            departments="Maintenance",
            responsible="Maintenance Lead",
            participants="Maintenance team",
            start_date=date.today(),
            end_date=date.today() + timedelta(days=60),
        ),
        dict(
            name="Incoming Quality Inspection",
            description="Set up incoming inspection for key purchased components.",
            target="Incoming defect rate < 0.5% for 90 days.",
            departments="Quality",
            responsible="QA Supervisor",
            participants="QA Technicians, Stores",
            start_date=date.today(),
            end_date=date.today() + timedelta(days=90),
        ),
    ]

    created_any = False
    for data in payload:
        key = dict(name=data["name"])
        _, created = get_or_create(Measure, **key, defaults=data)
        created_any = created_any or created
    return created_any


def _derive_due_at(start_date: Optional[date], end_date: Optional[date]) -> Optional[datetime]:
    if end_date:
        return datetime.combine(end_date, datetime.max.time())
    return None


def _seed_steps_for(assignment: "MeasureAssignment", titles: Iterable[str]):
    """
    Add steps (only if none exist yet for this assignment).
    """
    from app.models import AssignmentStep, MeasureAssignment
    if assignment.steps:
        return
    order = 0
    for t in titles:
        t = (t or "").strip()
        if not t:
            continue
        step = AssignmentStep(
            assignment_id=assignment.id,
            title=t,
            step=order,
            is_completed=False,
        )
        db.session.add(step)
        order += 1


def seed_assignments_with_steps():
    """
    Assign each measure to Acme Tooling and Bravo Plastics (demo),
    and add some example steps for each assignment.
    """
    from app.models import Company, Measure, MeasureAssignment
    acme = Company.query.filter_by(name="Acme Tooling").first()
    bravo = Company.query.filter_by(name="Bravo Plastics").first()
    measures = Measure.query.all()
    if not measures or not (acme or bravo):
        return False

    # Example default step sets keyed by measure name
    default_steps_map = {
        "5S Implementation": [
            "Define pilot area and ownership",
            "Sort (red-tag) unnecessary items",
            "Set in order with labels/shadow boards",
            "Shine: deep clean and fix abnormalities",
            "Standardize audit checklist",
            "Sustain: schedule weekly audits",
        ],
        "Preventive Maintenance Program": [
            "List critical equipment",
            "Define PM tasks & intervals",
            "Create PM calendar",
            "Train technicians",
            "Execute PM on schedule",
            "Review PM effectiveness monthly",
        ],
        "Incoming Quality Inspection": [
            "Identify key incoming parts",
            "Create acceptance criteria",
            "Setup inspection workstation",
            "Train inspectors",
            "Start inspection & log defects",
            "Weekly review with suppliers",
        ],
    }

    changed = False

    def upsert_assignment(company: Company, m: Measure, status: str = "In Progress"):
        nonlocal changed
        existing = MeasureAssignment.query.filter_by(company_id=company.id, measure_id=m.id).first()
        if existing:
            return existing
        a = MeasureAssignment(
            company_id=company.id,
            measure_id=m.id,
            status=status,
            start_date=m.start_date,
            end_date=m.end_date,
            target=m.target,
            departments=m.departments,
            responsible=m.responsible,
            participants=m.participants,
        )
        a.due_at = _derive_due_at(a.start_date, a.end_date)
        db.session.add(a)
        db.session.flush()  # get a.id
        _seed_steps_for(a, default_steps_map.get(m.name, []))
        changed = True
        return a

    for m in measures:
        if acme:
            upsert_assignment(acme, m, status="In Progress")
        if bravo:
            upsert_assignment(bravo, m, status="Not Started")

    return changed


# ---------- main ----------
def main():
    app = create_app()
    with app.app_context():
        ensure_tables()

        changed = False
        changed |= seed_admin()
        changed |= seed_companies()
        changed |= seed_company_users()
        changed |= seed_measures()
        changed |= seed_assignments_with_steps()

        if changed:
            db.session.commit()
            print("[seed] Done. Database updated.")
        else:
            print("[seed] Nothing to do. Data already present.")


if __name__ == "__main__":
    main()
