# app/routes/auth_routes.py
from urllib.parse import urlparse
from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_user, logout_user, login_required
from werkzeug.security import check_password_hash, generate_password_hash

from app.extensions import db
from app.models import User

auth_bp = Blueprint("auth", __name__)


def _is_safe_next(next_url: str) -> bool:
    """Only allow local relative URLs for `next` to avoid open-redirects."""
    if not next_url:
        return False
    p = urlparse(next_url)
    return (not p.scheme) and (not p.netloc) and next_url.startswith("/")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    """
    GET: always render the login page.
    POST: authenticate and redirect to appropriate home, honoring a safe `next`.
    """
    try:
        if request.method == "POST":
            email = request.form.get("email", "").strip()
            password = request.form.get("password", "")
            remember = bool(request.form.get("remember"))

            user = User.query.filter_by(email=email).first()
            if user and check_password_hash(user.password, password):
                login_user(user, remember=remember)

                next_url = request.args.get("next") or request.form.get("next")
                if next_url and _is_safe_next(next_url):
                    return redirect(next_url)

                # Default landings
                if user.role == "admin":
                    return redirect(url_for("admin.measure_history"))
                return redirect(url_for("company.dashboard"))

            flash("Invalid credentials.", "danger")
    except Exception as e:
        current_app.logger.error(f"Login error: {str(e)}")
        flash("An error occurred during login. Please try again.", "danger")

    # Always show the login form (also after failed POST)
    return render_template("login.html", next=request.args.get("next", ""))
    

@auth_bp.route("/logout")
@login_required
def logout():
    try:
        logout_user()
        flash("You have been logged out.", "info")
    except Exception as e:
        current_app.logger.error(f"Logout error: {str(e)}")
        flash("An error occurred during logout.", "warning")
    return redirect(url_for("auth.login"))


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    try:
        if request.method == "POST":
            email = request.form.get("email", "").strip()
            password = request.form.get("password", "")
            role = request.form.get("role", "company")

            if not email or not password:
                flash("Email and password are required.", "warning")
                return render_template("register.html")

            if User.query.filter_by(email=email).first():
                flash("Email is already registered.", "warning")
                return render_template("register.html")

            user = User(
                email=email,
                password=generate_password_hash(password),
                role=role,
                is_active=True,
            )
            db.session.add(user)
            db.session.commit()
            flash("Account created. You can now log in.", "success")
            return redirect(url_for("auth.login"))
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Registration error: {str(e)}")
        flash("An error occurred during registration. Please try again.", "danger")

    return render_template("register.html")





