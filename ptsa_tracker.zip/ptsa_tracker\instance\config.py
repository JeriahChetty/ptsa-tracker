# SMTP Configuration - Update with your actual values
MAIL_SERVER = "smtp.gmail.com"  # Or your email provider's SMTP server
MAIL_PORT = 587                 # Common TLS port (or 465 for SSL)
MAIL_USE_TLS = True             # Use TLS security
MAIL_USE_SSL = False            # Set to True if using port 465
MAIL_USERNAME = "your.actual.email@gmail.com"
MAIL_PASSWORD = "your-app-password"  # For Gmail, generate an App Password
MAIL_DEFAULT_SENDER = "PTSA Tracker <your.actual.email@gmail.com>"
