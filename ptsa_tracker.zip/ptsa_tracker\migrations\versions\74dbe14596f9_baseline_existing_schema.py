"""baseline existing schema

Revision ID: 74dbe14596f9
Revises: 
Create Date: 2025-08-22 09:05:28.691364+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '74dbe14596f9'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
