# app/routes/admin_routes.py
from __future__ import annotations

from datetime import datetime, timedelta
from io import BytesIO

from flask import (
    Blueprint,
    render_template,
    request,
    send_file,
    flash,
    redirect,
    url_for,
    abort,
    current_app,
)
from flask_login import login_required, current_user
from sqlalchemy.orm import joinedload
from werkzeug.security import generate_password_hash

from app.extensions import db
from app.models import (
    User,
    Company,
    Measure,
    MeasureStep,          # default steps for a measure (templates)
    MeasureAssignment,
    AssignmentStep,
    NotificationConfig,
    AssistanceRequest,
    Notification,  
)

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


# ---------------------------------------------------------------------------
# Admin guard (all routes require an authenticated admin)
# ---------------------------------------------------------------------------
@admin_bp.before_request
def _admins_only():
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login", next=request.path))
    if getattr(current_user, "role", "") != "admin":
        abort(403)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@admin_bp.route("/dashboard", methods=["GET"])
@login_required
def dashboard():
    now = datetime.utcnow()
    overdue_count = db.session.query(MeasureAssignment).filter(
        MeasureAssignment.due_at < now,
        MeasureAssignment.status != "Completed"
    ).count()
    stats = {
        "companies": db.session.query(Company).count(),
        "measures": db.session.query(Measure).count(),
        "not_started": db.session.query(MeasureAssignment).filter_by(status="Not Started").count(),
        "in_progress": db.session.query(MeasureAssignment).filter_by(status="In Progress").count(),
        "needs_assistance": db.session.query(MeasureAssignment).filter_by(status="Needs Assistance").count(),
        "completed": db.session.query(MeasureAssignment).filter_by(status="Completed").count(),
        "overdue": overdue_count,
    }
    recent = (
        MeasureAssignment.query.options(
            joinedload(MeasureAssignment.company),
            joinedload(MeasureAssignment.measure),
            joinedload(MeasureAssignment.steps),
        )
        .order_by(MeasureAssignment.created_at.desc())
        .limit(12)
        .all()
    )
    overdue = [
        a for a in recent if a.due_at and a.status != "Completed" and a.due_at < now
    ]
    return render_template("admin/dashboard.html", stats=stats, recent=recent, overdue=overdue, now=now)


# ---------------------------------------------------------------------------
# Measure History (filter + export)
# ---------------------------------------------------------------------------
@admin_bp.route("/measures/history", methods=["GET"])
@login_required
def measure_history():
    company_id = request.args.get("company_id", type=int)
    measure_id = request.args.get("measure_id", type=int)
    status = request.args.get("status", type=str)
    date_from = request.args.get("date_from", type=str)
    date_to = request.args.get("date_to", type=str)

    q = (
        db.session.query(MeasureAssignment)
        .join(Company, MeasureAssignment.company_id == Company.id)
        .join(Measure, MeasureAssignment.measure_id == Measure.id)
    )

    if company_id:
        q = q.filter(MeasureAssignment.company_id == company_id)
    if measure_id:
        q = q.filter(MeasureAssignment.measure_id == measure_id)
    if status:
        q = q.filter(MeasureAssignment.status == status)

    def _parse_dt(val: str | None):
        if not val:
            return None
        try:
            return datetime.fromisoformat(val)
        except Exception:
            return None

    df = _parse_dt(date_from)
    dt = _parse_dt(date_to)

    # prefer updated_at; fall back to created_at
    date_col = getattr(MeasureAssignment, "updated_at", None) or MeasureAssignment.created_at
    if df:
        q = q.filter(date_col >= df)
    if dt:
        q = q.filter(date_col <= dt)

    assignments = q.order_by(MeasureAssignment.id.desc()).all()
    companies = Company.query.order_by(Company.name.asc()).all()
    measures = Measure.query.order_by(Measure.name.asc()).all()

    return render_template(
        "admin/measure_history.html",
        assignments=assignments,
        companies=companies,
        measures=measures,
        selected=dict(
            company_id=company_id,
            measure_id=measure_id,
            status=status,
            date_from=date_from,
            date_to=date_to,
        ),
    )


@admin_bp.route("/measures/history/export", methods=["GET"])
@login_required
def measure_history_export():
    company_id = request.args.get("company_id", type=int)
    measure_id = request.args.get("measure_id", type=int)
    status = request.args.get("status", type=str)
    date_from = request.args.get("date_from", type=str)
    date_to = request.args.get("date_to", type=str)

    q = (
        db.session.query(MeasureAssignment)
        .join(Company, MeasureAssignment.company_id == Company.id)
        .join(Measure, MeasureAssignment.measure_id == Measure.id)
    )
    if company_id:
        q = q.filter(MeasureAssignment.company_id == company_id)
    if measure_id:
        q = q.filter(MeasureAssignment.measure_id == measure_id)
    if status:
        q = q.filter(MeasureAssignment.status == status)

    def _parse_dt(val: str | None):
        if not val:
            return None
        try:
            return datetime.fromisoformat(val)
        except Exception:
            return None

    df = _parse_dt(date_from)
    dt = _parse_dt(date_to)

    date_col = getattr(MeasureAssignment, "updated_at", None) or MeasureAssignment.created_at
    if df:
        q = q.filter(date_col >= df)
    if dt:
        q = q.filter(date_col <= dt)

    rows = []
    for a in q.all():
        rows.append(
            {
                "Assignment ID": a.id,
                "Company": getattr(a.company, "name", ""),
                "Measure": getattr(a.measure, "name", ""),
                "Status": a.status or "",
                "Due At": a.due_at.isoformat() if a.due_at else "",
                "Created At": a.created_at.isoformat() if a.created_at else "",
                "Updated At": getattr(a, "updated_at", None).isoformat()
                if getattr(a, "updated_at", None)
                else "",
                "Completed Steps": sum(
                    1 for s in getattr(a, "steps", []) if getattr(s, "is_completed", False)
                ),
                "Total Steps": len(getattr(a, "steps", [])),
            }
        )

    # Try XLSX first
    try:
        from openpyxl import Workbook  # type: ignore

        wb = Workbook()
        ws = wb.active
        ws.title = "Measure History"
        headers = (
            list(rows[0].keys())
            if rows
            else [
                "Assignment ID",
                "Company",
                "Measure",
                "Status",
                "Due At",
                "Created At",
                "Updated At",
                "Completed Steps",
                "Total Steps",
            ]
        )
        ws.append(headers)
        for r in rows:
            ws.append([r.get(h, "") for h in headers])
        buf = BytesIO()
        wb.save(buf)
        buf.seek(0)
        return send_file(
            buf,
            as_attachment=True,
            download_name="measure_history.xlsx",
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception:
        # Fallback to CSV
        headers = (
            list(rows[0].keys())
            if rows
            else [
                "Assignment ID",
                "Company",
                "Measure",
                "Status",
                "Due At",
                "Created At",
                "Updated At",
                "Completed Steps",
                "Total Steps",
            ]
        )
        out_lines = [",".join(headers)]
        for r in rows:
            out_lines.append(
                ",".join(str(r.get(h, "")).replace(",", ";") for h in headers)
            )
        buf = BytesIO()
        buf.write("\n".join(out_lines).encode("utf-8"))
        buf.seek(0)
        return send_file(
            buf, as_attachment=True, download_name="measure_history.csv", mimetype="text/csv"
        )


# ---------------------------------------------------------------------------
# Companies: create + list (admin registers company login)
# ---------------------------------------------------------------------------
@admin_bp.route("/companies", methods=["GET", "POST"])
@login_required
def companies():
    try:
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            region = request.form.get("region", "").strip()
            industry = request.form.get("industry_category", "").strip()
            tech = request.form.get("tech_resources", "").strip()
            human = request.form.get("human_resources", "").strip()
            membership = request.form.get("membership", "").strip()

            login_email = (request.form.get("login_email") or "").strip().lower()
            login_password = (request.form.get("login_password") or "").strip()

            measure_ids = request.form.getlist("assign_measure_ids")  # optional multi-select

            # basic validation
            if not name:
                flash("Company name is required.", "warning")
                return redirect(url_for("admin.companies"))
            if not login_email or not login_password:
                flash("Login email and temporary password are required.", "warning")
                return redirect(url_for("admin.companies"))

            # duplicates
            if Company.query.filter_by(name=name).first():
                flash("A company with that name already exists.", "warning")
                return redirect(url_for("admin.companies"))
            if User.query.filter_by(email=login_email).first():
                flash("That login email is already in use.", "warning")
                return redirect(url_for("admin.companies"))

            # create company
            c = Company(
                name=name,
                region=region or None,
                industry_category=industry or None,
                tech_resources=tech or None,
                human_resources=human or None,
                membership=membership or None,
            )
            db.session.add(c)
            db.session.flush()  # get c.id

            # create the company user
            u = User(
                email=login_email,
                password=generate_password_hash(login_password),
                role="company",
                is_active=True,
                company_id=c.id,
            )
            db.session.add(u)

            # assign measures immediately (optional)
            for mid in measure_ids:
                m = Measure.query.get(int(mid))
                if not m:
                    continue
                a = MeasureAssignment(
                    company_id=c.id,
                    measure_id=m.id,
                    status="Not Started",  # progress only when steps begin
                    created_at=datetime.utcnow(),
                    duration_days=m.default_duration_days,
                    urgency=m.default_urgency,
                    timeframe_date=m.default_timeframe_date,
                    target=m.target,
                    departments=m.departments,
                    responsible=m.responsible,
                    participants=m.participants,
                )
                # derive due_at
                if a.timeframe_date:
                    a.due_at = datetime.combine(a.timeframe_date, datetime.max.time())
                elif a.duration_days:
                    a.due_at = datetime.utcnow() + timedelta(days=a.duration_days)
                db.session.add(a)

            db.session.commit()
            msg = f"Company '{c.name}' created and login {u.email} registered."
            if measure_ids:
                msg += f" {len(measure_ids)} measure(s) assigned."
            flash(msg, "success")
            return redirect(url_for("admin.companies"))

        companies = Company.query.order_by(Company.name.asc()).all()
        measures = Measure.query.order_by(Measure.name.asc()).all()
        return render_template("admin/companies.html", companies=companies, measures=measures)
    except Exception as e:
        db.session.rollback()
        flash(f"An error occurred: {str(e)}", "danger")
        return redirect(url_for("admin.companies"))


# Quick alias to jump to the wizard (handy for “Proceed to Measures” buttons)
@admin_bp.route("/companies/<int:company_id>/proceed", methods=["GET"])
@login_required
def proceed_to_measures(company_id: int):
    return redirect(url_for("admin.company_measures_wizard", company_id=company_id))


# ---------------------------------------------------------------------------
# Measures: list + create + assign (single)
# ---------------------------------------------------------------------------
@admin_bp.route("/measures", methods=["GET"])
@login_required
def measures():
    measures = Measure.query.order_by(Measure.name.asc()).all()
    companies = Company.query.order_by(Company.name.asc()).all()
    return render_template("admin/measures.html", measures=measures, companies=companies)


@admin_bp.route("/measures/new", methods=["POST"])
@login_required
def create_measure():
    try:
        name = request.form.get("name", "").strip()
        measure_detail = request.form.get("measure_detail", "").strip()
        target = request.form.get("target", "").strip()
        departments = request.form.get("departments", "").strip()
        responsible = request.form.get("responsible", "").strip()
        participants = request.form.get("participants", "").strip()
        start_date = request.form.get("start_date")
        end_date = request.form.get("end_date")
        default_duration_days = request.form.get("default_duration_days", type=int)
        default_urgency = request.form.get("default_urgency", type=int)
        default_timeframe_date = request.form.get("default_timeframe_date") or None

        if not name:
            flash("Measure name is required.", "warning")
            return redirect(url_for("admin.measures"))

        m = Measure(
            name=name,
            measure_detail=measure_detail or None,
            target=target or None,
            departments=departments or None,
            responsible=responsible or None,
            participants=participants or None,
            start_date=datetime.fromisoformat(start_date).date() if start_date else None,
            end_date=datetime.fromisoformat(end_date).date() if end_date else None,
            default_duration_days=default_duration_days,
            default_urgency=default_urgency,
            default_timeframe_date=(
                datetime.fromisoformat(default_timeframe_date).date()
                if default_timeframe_date
                else None
            ),
        )
        db.session.add(m)
        db.session.flush()

        steps_text = request.form.get("default_steps", "").strip()
        if steps_text:
            for idx, line in enumerate([s.strip() for s in steps_text.splitlines() if s.strip()]):
                db.session.add(MeasureStep(measure_id=m.id, title=line, order_index=idx))

        db.session.commit()
        flash(f"Measure '{m.name}' created.", "success")
        return redirect(url_for("admin.measures"))
    except Exception as e:
        db.session.rollback()
        flash(f"An error occurred: {str(e)}", "danger")
        return redirect(url_for("admin.measures"))


@admin_bp.route("/measures/assign", methods=["POST"])
@login_required
def assign_measure():
    """
    Assign a measure to a company.
    """
    try:
        measure_id = request.form.get("measure_id", type=int)
        company_id = request.form.get("company_id", type=int)
        end_date = request.form.get("end_date")
        urgency = request.form.get("urgency", type=int, default=1)
        
        if not measure_id or not company_id:
            flash("Missing required fields for assignment.", "danger")
            return redirect(url_for("admin.measures"))
        
        # Check if measure is already assigned to this company
        existing = MeasureAssignment.query.filter_by(
            measure_id=measure_id, company_id=company_id
        ).first()
        if existing:
            flash(f"This measure is already assigned to this company.", "warning")
            return redirect(url_for("admin.measures"))
        
        # Create the assignment
        measure = Measure.query.get_or_404(measure_id)
        company = Company.query.get_or_404(company_id)
        
        assignment = MeasureAssignment(
            measure_id=measure_id,
            company_id=company_id,
            status="Not Started",
            urgency=urgency,
            start_date=datetime.now().date(),
            end_date=datetime.strptime(end_date, "%Y-%m-%d").date() if end_date else None,
            
            # Snapshot measure meta
            target=measure.target,
            departments=measure.departments,
            responsible=measure.responsible,
            participants=measure.participants,
        )
        db.session.add(assignment)
        db.session.commit()
        
        flash(f"Measure '{measure.name}' assigned to '{company.name}'.", "success")
        return redirect(url_for("admin.measures"))
    except Exception as e:
        db.session.rollback()
        flash(f"An error occurred: {str(e)}", "danger")
        return redirect(url_for("admin.measures"))


# ---------------------------------------------------------------------------
# Notification Settings
# ---------------------------------------------------------------------------
@admin_bp.route("/notifications/settings", methods=["GET", "POST"])
@login_required
def notification_settings():
    cfg = NotificationConfig.query.get(1)
    if not cfg:
        cfg = NotificationConfig(id=1)  # defaults
        db.session.add(cfg)
        db.session.commit()

    if request.method == "POST":
        lead_days = max(0, int(request.form.get("lead_days") or cfg.lead_days))
        send_time = (request.form.get("send_time") or "").strip()  # "HH:MM"
        try:
            hour_s, min_s = send_time.split(":")
            hour = max(0, min(23, int(hour_s)))
            minute = max(0, min(59, int(min_s)))
        except Exception:
            flash("Invalid time. Use HH:MM (00–23:00–59).", "warning")
            return redirect(url_for("admin.notification_settings"))

        cfg.lead_days = lead_days
        cfg.send_hour_utc = hour
        cfg.send_minute_utc = minute
        db.session.commit()
        flash("Notification settings saved.", "success")
        return redirect(url_for("admin.notification_settings"))

    current_hhmm = f"{cfg.send_hour_utc:02d}:{cfg.send_minute_utc:02d}"
    return render_template("admin/notification_settings.html", cfg=cfg, current_hhmm=current_hhmm)


# ---------------------------------------------------------------------------
# Needs Assistance queue + decision
# ---------------------------------------------------------------------------
from sqlalchemy.orm import joinedload

@admin_bp.route("/assistance")
@login_required
def assistance_queue():
    if getattr(current_user, "role", "") != "admin":
        abort(403)

    # --- Backfill once: ensure every “Needs Assistance” assignment has an open request
    needs = (MeasureAssignment.query
             .filter(MeasureAssignment.status == "Needs Assistance")
             .all())
    new_count = 0
    for a in needs:
        if not AssistanceRequest.query.filter_by(assignment_id=a.id, decision="open").first():
            db.session.add(AssistanceRequest(
                assignment_id=a.id,
                requested_by_id=None,
                prev_status=None,
                decision="open",
            ))
            new_count += 1
    if new_count:
        db.session.commit()

    # Eager-load what the template needs
    eager = [
        joinedload(AssistanceRequest.assignment)
            .joinedload(MeasureAssignment.company),
        joinedload(AssistanceRequest.assignment)
            .joinedload(MeasureAssignment.measure),
        joinedload(AssistanceRequest.requested_by),
        joinedload(AssistanceRequest.decided_by),
    ]

    open_reqs = (AssistanceRequest.query
                 .options(*eager)
                 .filter(AssistanceRequest.decision == "open")
                 .order_by(AssistanceRequest.requested_at.desc())
                 .all())

    recent = (AssistanceRequest.query
              .options(*eager)
              .filter(AssistanceRequest.decision.in_(["resolved", "not_resolved"]))
              .order_by(AssistanceRequest.decided_at.desc())
              .limit(20)
              .all())

    return render_template("admin/assistance.html", open_reqs=open_reqs, recent=recent)



@admin_bp.route("/assistance/<int:req_id>/decide", methods=["POST"])
@login_required
def assistance_decide(req_id: int):
    # (guard is duplicated here in case before_request is changed later)
    if getattr(current_user, "role", "") != "admin":
        abort(403)

    action = (request.form.get("action") or "").strip()  # "resolved" or "not_resolved"
    notes = (request.form.get("notes") or "").strip()

    req = AssistanceRequest.query.get_or_404(req_id)
    if req.decision != "open":
        flash("This request has already been decided.", "info")
        return redirect(url_for("admin.assistance_queue"))

    a = req.assignment
    measure = getattr(a, "measure", None)
    measure_name = getattr(measure, "name", "Measure")

    notif_kind = None
    notif_subject = None
    notif_body = None

    if action == "resolved":
        # Revert assignment back to its prior status (or In Progress)
        a.status = req.prev_status or "In Progress"
        req.decision = "resolved"

        # Company-side notification: assistance resolved
        notif_kind = "assistance_resolved"
        notif_subject = f"Assistance resolved: {measure_name}"
        notif_body = (
            f"Your assistance request for '{measure_name}' has been marked as resolved by an administrator. "
            f"The measure status has been set back to '{a.status}'."
        )
    elif action == "not_resolved":
        # Keep it flagged; no “resolved” notification
        a.status = "Needs Assistance"
        req.decision = "not_resolved"
    else:
        flash("Invalid action.", "warning")
        return redirect(url_for("admin.assistance_queue"))

    req.decision_notes = notes or None
    req.decided_at = datetime.utcnow()
    req.decided_by_id = getattr(current_user, "id", None)

    # Create the notification if the model exists (and only once per assignment/kind)
    if notif_kind:
        try:
            from app.models import Notification  # lazy import; optional model
            exists = Notification.query.filter_by(
                assignment_id=a.id, kind=notif_kind
            ).first()
            if not exists:
                db.session.add(Notification(
                    company_id=a.company_id,
                    user_id=None,
                    assignment_id=a.id,
                    kind=notif_kind,
                    subject=notif_subject,
                    body=notif_body,
                    notify_at=datetime.utcnow(),
                ))
        except Exception:
            # If Notification model/table doesn't exist, skip silently
            pass

    db.session.commit()
    flash("Assistance request updated.", "success")
    return redirect(url_for("admin.assistance_queue"))



# ---------------------------------------------------------------------------
# Company → Measures wizard (create multiple measures & assign to this company)
# ---------------------------------------------------------------------------
@admin_bp.route("/companies/<int:company_id>/wizard", methods=["GET", "POST"])
@login_required
def company_measures_wizard(company_id: int):
    company = Company.query.get_or_404(company_id)

    if request.method == "GET":
        return render_template("admin/company_measures_wizard.html", company=company)

    # POST: accept multiple measures in one go
    names = [n.strip() for n in request.form.getlist("measure_name") if n.strip()]
    descs = request.form.getlist("measure_description")
    targs = request.form.getlist("measure_target")
    depts = request.form.getlist("measure_departments")
    resp = request.form.getlist("measure_responsible")
    parts = request.form.getlist("measure_participants")
    durs  = request.form.getlist("measure_duration_days")
    urg   = request.form.getlist("measure_urgency")
    dates = request.form.getlist("measure_timeframe_date")
    steps = request.form.getlist("measure_steps")

    created_count = 0
    assigned_count = 0

    for i, name in enumerate(names):
        description = (descs[i].strip() if i < len(descs) else "") or None
        target = (targs[i].strip() if i < len(targs) else "") or None
        departments = (depts[i].strip() if i < len(depts) else "") or None
        responsible = (resp[i].strip() if i < len(resp) else "") or None
        participants = (parts[i].strip() if i < len(parts) else "") or None

        def _to_int(lst, idx):
            try:
                return int(lst[idx]) if idx < len(lst) and lst[idx] != "" else None
            except Exception:
                return None

        duration_days = _to_int(durs, i)
        urgency = _to_int(urg, i)

        timeframe_date = None
        if i < len(dates) and dates[i].strip():
            try:
                timeframe_date = datetime.fromisoformat(dates[i].strip()).date()
            except Exception:
                timeframe_date = None

        steps_block = steps[i] if i < len(steps) else ""
        step_lines = [s.strip() for s in (steps_block or "").splitlines() if s.strip()]

        # Find or create measure by name
        m = Measure.query.filter_by(name=name).first()
        if not m:
            m = Measure(
                name=name,
                description=description,
                target=target,
                departments=departments,
                responsible=responsible,
                participants=participants,
                default_duration_days=duration_days,
                default_urgency=urgency,
                default_timeframe_date=timeframe_date,
            )
            db.session.add(m)
            db.session.flush()
            created_count += 1

            # Add default steps to the measure
            for idx, line in enumerate(step_lines):
                db.session.add(MeasureStep(measure_id=m.id, title=line, order_index=idx))

        # Create assignment for this company
        a = MeasureAssignment(
            company_id=company.id,
            measure_id=m.id,
            status="Not Started",  # <-- default now aligns with your rule
            created_at=datetime.utcnow(),
            duration_days=duration_days if duration_days is not None else m.default_duration_days,
            urgency=urgency if urgency is not None else m.default_urgency,
            timeframe_date=timeframe_date if timeframe_date is not None else m.default_timeframe_date,
            target=m.target,
            departments=m.departments,
            responsible=m.responsible,
            participants=m.participants,
        )
        # derive due_at
        if a.timeframe_date:
            a.due_at = datetime.combine(a.timeframe_date, datetime.max.time())
        elif a.duration_days:
            a.due_at = datetime.utcnow() + timedelta(days=a.duration_days)

        db.session.add(a)
        db.session.flush()

        # Clone default steps from measure into this assignment
        defaults = (
            MeasureStep.query.filter_by(measure_id=m.id)
            .order_by(MeasureStep.order_index.asc())
            .all()
        )
        for idx, s in enumerate(defaults):
            db.session.add(
                AssignmentStep(
                    assignment_id=a.id,
                    title=s.title,
                    order_index=idx,
                    is_completed=False,
                )
            )
        assigned_count += 1

    db.session.commit()

    flash(
        f"Created {created_count} new measure(s) and assigned {assigned_count} measure(s) to {company.name}.",
        "success",
    )
    return redirect(url_for("admin.measures"))


# --- CRUD for Companies ---
@admin_bp.route("/companies/<int:company_id>")
@login_required
def company_profile(company_id):
    company = Company.query.get_or_404(company_id)
    assignments = MeasureAssignment.query.filter_by(company_id=company.id).all()
    return render_template("admin/company_profile.html", company=company, assignments=assignments)

@admin_bp.route("/companies/<int:company_id>/edit", methods=["GET", "POST"])
@login_required
def edit_company(company_id):
    company = Company.query.get_or_404(company_id)
    if request.method == "POST":
        company.name = request.form.get("name", company.name)
        company.region = request.form.get("region", company.region)
        company.industry_category = request.form.get("industry_category", company.industry_category)
        company.tech_resources = request.form.get("tech_resources", company.tech_resources)
        company.human_resources = request.form.get("human_resources", company.human_resources)
        company.membership = request.form.get("membership", company.membership)
        db.session.commit()
        flash("Company updated.", "success")
        return redirect(url_for("admin.company_profile", company_id=company.id))
    return render_template("admin/edit_company.html", company=company)

@admin_bp.route("/companies/<int:company_id>/delete", methods=["POST"])
@login_required
def delete_company(company_id):
    try:
        company = Company.query.get_or_404(company_id)
        db.session.delete(company)
        db.session.commit()
        flash("Company deleted.", "success")
        return redirect(url_for("admin.companies"))
    except Exception as e:
        db.session.rollback()
        flash(f"An error occurred: {str(e)}", "danger")
        return redirect(url_for("admin.companies"))

# --- CRUD for Measures ---
@admin_bp.route("/measures/<int:measure_id>")
@login_required
def measure_profile(measure_id):
    measure = Measure.query.get_or_404(measure_id)
    return render_template("admin/measure_profile.html", measure=measure)

@admin_bp.route("/measures/<int:measure_id>/edit", methods=["GET", "POST"])
@login_required
def edit_measure(measure_id):
    measure = Measure.query.get_or_404(measure_id)
    if request.method == "POST":
        measure.name = request.form.get("name", measure.name)
        measure.measure_detail = request.form.get("measure_detail", measure.measure_detail)
        measure.target = request.form.get("target", measure.target)
        measure.departments = request.form.get("departments", measure.departments)
        measure.responsible = request.form.get("responsible", measure.responsible)
        measure.participants = request.form.get("participants", measure.participants)
        measure.start_date = request.form.get("start_date", measure.start_date)
        measure.end_date = request.form.get("end_date", measure.end_date)
        db.session.commit()
        flash("Measure updated.", "success")
        return redirect(url_for("admin.measure_profile", measure_id=measure.id))
    return render_template("admin/edit_measure.html", measure=measure)

@admin_bp.route("/measures/<int:measure_id>/delete", methods=["POST"])
@login_required
def delete_measure(measure_id):
    """Delete a measure and all related records."""
    try:
        from flask import jsonify
        measure = Measure.query.get_or_404(measure_id)

        # Manually delete related assignments first to ensure cascades work reliably
        # This is more explicit and safer with complex relationships.
        MeasureAssignment.query.filter_by(measure_id=measure.id).delete()
        
        # Now delete the measure itself. Its own steps will be cascaded.
        db.session.delete(measure)
        
        db.session.commit()
        
        return jsonify({"success": True, "message": "Measure deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting measure {measure_id}: {str(e)}")
        return jsonify({"success": False, "message": str(e)}), 500


@admin_bp.route("/steps/<int:step_id>/delete", methods=["POST"])
@login_required
def delete_step(step_id):
    """Delete a measure step."""
    try:
        from flask import jsonify
        step = MeasureStep.query.get_or_404(step_id)
        db.session.delete(step)
        db.session.commit()
        return jsonify({"success": True, "message": "Step deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting step: {str(e)}")
        return jsonify({"success": False, "message": str(e)}), 500


@admin_bp.route("/save_measures", methods=["POST"])
@login_required
def save_measures():
    """Save all measures and their steps from the form."""
    try:
        measures_data = request.form.to_dict(flat=False)
        
        # Process all submitted measures
        for i in range(len(measures_data.get('measures[][name]', []))):
            measure_id = measures_data.get(f'measures[{i}][id]', [''])[0]
            name = measures_data.get(f'measures[{i}][name]', [''])[0]
            target = measures_data.get(f'measures[{i}][target]', [''])[0]
            measure_detail = measures_data.get(f'measures[{i}][measure_detail]', [''])[0]
            departments = measures_data.get(f'measures[{i}][departments]', [''])[0]
            responsible = measures_data.get(f'measures[{i}][responsible]', [''])[0]
            participants = measures_data.get(f'measures[{i}][participants]', [''])[0]
            
            if not name:
                continue  # Skip empty measures
                
            # Create or update measure
            if measure_id:
                measure = Measure.query.get(measure_id)
                if not measure:
                    continue
            else:
                measure = Measure()
                db.session.add(measure)
                
            # Update measure fields
            measure.name = name
            measure.target = target
            measure.measure_detail = measure_detail
            measure.departments = departments
            measure.responsible = responsible
            measure.participants = participants
            
            db.session.flush()
            
            # Process steps for this measure
            step_titles = measures_data.get(f'measures[{i}][steps][][title]', [])
            step_numbers = measures_data.get(f'measures[{i}][steps][][step]', [])
            step_ids = measures_data.get(f'measures[{i}][steps][][id]', [])
            
            # Keep track of processed steps to delete any that aren't in the form
            processed_step_ids = []
            
            for j in range(len(step_titles)):
                step_id = step_ids[j] if j < len(step_ids) else ''
                step_title = step_titles[j]
                step_number = int(step_numbers[j]) if j < len(step_numbers) and step_numbers[j].isdigit() else j
                
                if not step_title:
                    continue  # Skip empty steps
                    
                # Create or update step
                if step_id:
                    step = MeasureStep.query.get(step_id)
                    if not step or step.measure_id != measure.id:
                        step = MeasureStep(measure_id=measure.id)
                        db.session.add(step)
                else:
                    step = MeasureStep(measure_id=measure.id)
                    db.session.add(step)
                
                step.title = step_title
                step.step = step_number
                
                db.session.flush()
                processed_step_ids.append(step.id)
    
            # Delete steps that weren't in the form
        if measure_id:
            MeasureStep.query.filter(
                MeasureStep.measure_id == measure.id,
                ~MeasureStep.id.in_(processed_step_ids) if processed_step_ids else True
            ).delete(synchronize_session=False)
        
        db.session.commit()
        flash('Measures saved successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error saving measures: {str(e)}")
        flash(f'Error saving measures: {str(e)}', 'danger')
        
    return redirect(url_for('admin.measures'))


from flask import jsonify, request
from app.models import Measure, Step, db

@admin_bp.route('/measures/order', methods=['GET'])
@login_required
def manage_measure_order():
    """Page to manage the order of measures"""
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('main.index'))
        
    measures = Measure.query.order_by(Measure.order).all()
    return render_template('admin/measure_order.html', measures=measures)

@admin_bp.route('/steps/order/<int:measure_id>', methods=['GET'])
@login_required
def manage_step_order(measure_id):
    """Page to manage the order of steps for a specific measure"""
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('main.index'))
        
    measure = Measure.query.get_or_404(measure_id)
    steps = Step.query.filter_by(measure_id=measure_id).order_by(Step.order).all()
    return render_template('admin/step_order.html', measure=measure, steps=steps)

@admin_bp.route('/api/measures/update-order', methods=['POST'])
@login_required
def update_measure_order():
    """API endpoint to update measure order"""
    if not current_user.is_admin:
        return jsonify({"error": "Access denied"}), 403
    
    order_data = request.json
    
    try:
        for item in order_data:
            measure = Measure.query.get(item['id'])
            if measure:
                measure.order = item['order']
        
        db.session.commit()
        return jsonify({"success": True})
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@admin_bp.route('/api/steps/update-order', methods=['POST'])
@login_required
def update_step_order():
    """API endpoint to update step order"""
    if not current_user.is_admin:
        return jsonify({"error": "Access denied"}), 403
    
    order_data = request.json
    
    try:
        for item in order_data:
            step = Step.query.get(item['id'])
            if step:
                step.order = item['order']
        
        db.session.commit()
        return jsonify({"success": True})
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


