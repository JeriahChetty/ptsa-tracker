import os
from app import create_app

# allow .env if you want local testing without systemd EnvironmentFile
if os.path.exists(".env"):
    from dotenv import load_dotenv
    load_dotenv(".env")

app = create_app()

# Optional: health check
@app.get("/healthz")
def health():
    return {"status": "ok"}, 200

if __name__ == "__main__":
    app.run()
