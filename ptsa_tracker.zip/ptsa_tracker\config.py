
# instance/config.py
SECRET_KEY = "change-me-32+chars"
SQLALCHEMY_DATABASE_URI = "sqlite:///ptsa.db"  # or absolute path if you prefer
SQLALCHEMY_TRACK_MODIFICATIONS = False

MAIL_SERVER = "smtp.gmail.com"
MAIL_PORT = 587
MAIL_USE_TLS = True
MAIL_USE_SSL = False
MAIL_USERNAME = "you@gmail.com"
MAIL_PASSWORD = "your-app-password"
MAIL_DEFAULT_SENDER = "ED Tracker <you@gmail.com>"
